Creative Commons License Attribution 2.5 
========================================
http://creativecommons.org/licenses/by/2.5/
