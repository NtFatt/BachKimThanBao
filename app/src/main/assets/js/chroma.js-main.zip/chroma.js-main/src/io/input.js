export default {
    format: {},
    autodetect: []
};
