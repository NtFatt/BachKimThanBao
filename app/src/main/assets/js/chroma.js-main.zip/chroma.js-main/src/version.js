// this gets updated automatically
export const version = '3.1.2';
