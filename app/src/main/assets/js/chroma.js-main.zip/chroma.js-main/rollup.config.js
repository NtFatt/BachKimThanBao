import buble from '@rollup/plugin-buble';
import license from 'rollup-plugin-license';
import path from 'path';
import terser from '@rollup/plugin-terser';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const minify = !process.env.ROLLUP_WATCH && !process.env.DEV;
/** globals process, __dirname **/

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export default [
    bundle('index.umd.js', 'chroma'),
    bundle('index.umd.light.js', 'chroma-light')
];

function bundle(input, target) {
    return {
        input,
        output: {
            file: `dist/${target}${minify ? '.min' : ''}.cjs`,
            format: 'umd',
            globals: {}, // If you have any external dependencies, list them here
            exports: 'default',
            name: 'chroma'
        },
        plugins: [
            // If we're building for production (npm run build
            // instead of npm run dev), transpile and minify
            buble({
                transforms: { dangerousForOf: true }
            }),
            minify &&
                terser({
                    mangle: true
                }),
            license({
                sourcemap: true,
                //cwd: '.', // Default is process.cwd()

                banner: {
                    content: {
                        file: path.join(__dirname, 'LICENSE')
                    }
                }
            })
        ]
    };
}
